"""Evidence memory: shared, append-only store accumulated across DAG nodes.

This is the contract that lets dependent hops resolve placeholders from prior
answers, and that gives the synthesizer a unified pool to ground citations in.
"""

from __future__ import annotations

import re
from typing import Any, Iterable

from .models import AnswerEntry, Chunk


# Matches {h1} or {h1.answer} or {h1.field}
_PLACEHOLDER_RE = re.compile(r"\{(\w+)(?:\.(\w+))?\}")


class EvidenceMemory:
    """Shared memory across the DAG. Append-only within an iteration."""

    def __init__(self) -> None:
        self.chunks_pool: dict[str, Chunk] = {}  # dedup by chunk_id
        self.answer_log: dict[str, AnswerEntry] = {}  # one entry per completed node
        self.doc_set: set[str] = set()  # active doc_ids surfaced so far

    # ---- writes ----

    def add_chunks(self, chunks: Iterable[Chunk], node_id: str) -> None:
        for c in chunks:
            if c.chunk_id in self.chunks_pool:
                # Same chunk surfaced by multiple nodes — record provenance, don't duplicate
                self.chunks_pool[c.chunk_id].written_by.add(node_id)
            else:
                c.written_by.add(node_id)
                self.chunks_pool[c.chunk_id] = c

    def write_answer(self, entry: AnswerEntry) -> None:
        self.answer_log[entry.node_id] = entry

    def add_docs(self, doc_ids: Iterable[str]) -> None:
        self.doc_set.update(doc_ids)

    # ---- placeholder resolution ----

    def resolve_placeholders(self, template: Any) -> Any:
        """Substitute {hN} or {hN.answer} with the prior node's answer.

        Leaves unresolved placeholders intact (they will surface as obvious
        bugs in the downstream LLM call rather than silent failures).
        """
        if not isinstance(template, str):
            return template

        def _replace(match: re.Match) -> str:
            node_id = match.group(1)
            field_name = match.group(2) or "answer"
            entry = self.answer_log.get(node_id)
            if entry is None:
                return match.group(0)  # leave unresolved
            if field_name == "answer":
                return entry.answer
            # Extension point: support {hN.docs}, {hN.value}, etc.
            return entry.answer

        return _PLACEHOLDER_RE.sub(_replace, template)

    def resolve_args(self, args: dict[str, Any]) -> dict[str, Any]:
        return {k: self.resolve_placeholders(v) for k, v in args.items()}

    def has_unresolved_placeholders(self, args: dict[str, Any]) -> list[str]:
        unresolved: list[str] = []
        for v in args.values():
            if isinstance(v, str):
                for m in _PLACEHOLDER_RE.finditer(v):
                    unresolved.append(m.group(0))
        return unresolved

    # ---- inspection ----

    def summary(self) -> dict[str, int]:
        return {
            "chunks_pool_size": len(self.chunks_pool),
            "answer_log_size": len(self.answer_log),
            "doc_set_size": len(self.doc_set),
        }
