"""Tool interfaces and demo mocks.

In production you will:
  1. Replace MockRAGBackend with a thin wrapper around your existing multi-doc
     RAG endpoint (the one that does similarity search → top-10k → reranker →
     top-50 → answer over a given doc_id set).
  2. Replace MockDocCatalog with your document-level discovery index (one
     embedding per doc summary, optionally hybrid with BM25 over titles + summaries).
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

from .models import Chunk


# ---- abstract interfaces (subclass these in production) ----


class DocCatalog(ABC):
    """Document-level discovery: searches over doc summaries / metadata."""

    @abstractmethod
    def find(self, query: str, k: int = 20) -> list[dict]:
        """Return [{'doc_id', 'title', 'summary', 'score'}], ranked."""


class RAGBackend(ABC):
    """Your existing multi-document RAG endpoint.

    Contract: given a query and a list of doc_ids, run the similarity → rerank →
    answer pipeline scoped to those docs. Return both the top-N chunks (for the
    evidence pool) and a short structured answer.
    """

    @abstractmethod
    def query(self, query: str, doc_ids: list[str]) -> dict:
        """Return {'chunks': list[Chunk], 'answer': str}."""


# ---- demo mocks ----


MOCK_DOCS: dict[str, dict[str, Any]] = {
    # --- Apple ---
    "doc_apple_10k_2023": {
        "title": "Apple Inc. Form 10-K, FY2023",
        "summary": (
            "Annual report for fiscal year ended Sept 30, 2023. Total revenue $383.3B. "
            "Share-based compensation expense was $10.83B (up from $9.04B in FY2022). "
            "Stock repurchases totaled $77.55B; dividends declared $15.03B. "
            "Effective tax rate 14.7%. R&D spending $29.9B."
        ),
        "keywords": ["apple", "10-k", "2023", "fy2023", "share-based", "sbc", "compensation",
                     "buyback", "repurchase", "dividend", "personnel", "compensation"],
    },
    "doc_apple_10k_2022": {
        "title": "Apple Inc. Form 10-K, FY2022",
        "summary": (
            "FY2022 10-K, fiscal year ended Sept 24, 2022. Share-based compensation expense "
            "was $9.04B (vs $7.91B in FY2021). Stock repurchases $89.4B. Revenue $394.3B."
        ),
        "keywords": ["apple", "10-k", "2022", "fy2022", "share-based", "sbc", "compensation",
                     "buyback", "personnel"],
    },
    "doc_apple_10k_2021": {
        "title": "Apple Inc. Form 10-K, FY2021",
        "summary": (
            "FY2021 10-K, fiscal year ended Sept 25, 2021. Share-based compensation expense "
            "was $7.91B. Revenue $365.8B."
        ),
        "keywords": ["apple", "10-k", "2021", "fy2021", "share-based", "sbc", "compensation",
                     "personnel"],
    },
    # --- Visa ---
    "doc_visa_10k_2023": {
        "title": "Visa Inc. Form 10-K, FY2023",
        "summary": (
            "Annual report for fiscal year ended Sept 30, 2023. Personnel expense $5.59B "
            "(up from $4.99B in FY2022). Total operating expenses $11.65B. Employees ~28,800."
        ),
        "keywords": ["visa", "10-k", "2023", "fy2023", "personnel", "compensation", "employees"],
    },
    "doc_visa_10k_2022": {
        "title": "Visa Inc. Form 10-K, FY2022",
        "summary": (
            "FY2022 10-K, fiscal year ended Sept 30, 2022. Personnel expense $4.99B "
            "(up from $4.00B in FY2021)."
        ),
        "keywords": ["visa", "10-k", "2022", "fy2022", "personnel", "compensation"],
    },
    "doc_visa_10k_2021": {
        "title": "Visa Inc. Form 10-K, FY2021",
        "summary": (
            "FY2021 10-K, fiscal year ended Sept 30, 2021. Personnel expense $4.00B."
        ),
        "keywords": ["visa", "10-k", "2021", "fy2021", "personnel", "compensation"],
    },
    # --- Chevron ---
    "doc_chevron_10k_2023": {
        "title": "Chevron Corporation Form 10-K, FY2023",
        "summary": (
            "Annual report for 2023. Discusses renewable energy strategy across the value "
            "chain: upstream renewable natural gas (RNG) production via Renewable Energy "
            "Group acquired in 2022, hydrogen partnerships including with Iwatani for "
            "California stations; downstream Beyond6 compressed natural gas distribution "
            "network spanning 59 stations; petrochemical joint ventures with Phillips 66 "
            "(CPChem) exploring renewable feedstocks. Mentions 11 distinct renewable "
            "initiatives across the filing."
        ),
        "keywords": ["chevron", "10-k", "2023", "renewable", "rng", "hydrogen", "beyond6",
                     "value chain", "petrochemical", "joint venture", "cpchem", "sustainability"],
    },
    # --- NVIDIA ---
    "doc_nvidia_10q_q1_fy2025": {
        "title": "NVIDIA Corporation Form 10-Q, Q1 FY2025 (ended Apr 28, 2024)",
        "summary": (
            "Quarterly report for Q1 FY2025. Cash flow hedge accumulated unrealized "
            "loss net of $42M for the quarter (gross loss $58M, gross gain $16M). "
            "Hedge positions primarily USD/TWD and USD/INR for operational FX exposure."
        ),
        "keywords": ["nvidia", "10-q", "q1 fy2025", "cash flow hedge", "unrealized",
                     "hedge", "fx"],
    },
    "doc_nvidia_10q_q2_fy2024": {
        "title": "NVIDIA Corporation Form 10-Q, Q2 FY2024 (ended Jul 30, 2023)",
        "summary": (
            "Quarterly report for Q2 FY2024. Cash flow hedge accumulated unrealized "
            "gain net of $31M for the quarter. Conditions favorable for USD-strength "
            "hedges as the dollar strengthened against TWD."
        ),
        "keywords": ["nvidia", "10-q", "q2 fy2024", "cash flow hedge", "unrealized",
                     "hedge", "fx"],
    },
    # --- Goldman Sachs / Amex ---
    "doc_goldman_10k_2023": {
        "title": "The Goldman Sachs Group, Inc. Form 10-K, FY2023",
        "summary": (
            "Annual report covering 2023. Discusses Value-at-Risk (VaR) methodology — "
            "99% confidence, one-day horizon, historical simulation. Average daily VaR "
            "was $113M for 2023, with peak of $145M. Market-making business is the "
            "primary driver of market risk."
        ),
        "keywords": ["goldman", "10-k", "2023", "var", "value at risk", "market risk",
                     "risk management"],
    },
    "doc_amex_10k_2023": {
        "title": "American Express Company Form 10-K, FY2023",
        "summary": (
            "Annual report covering 2023. Credit risk is primary; non-interest revenue "
            "from discount fees on card spending ($28.4B). Total provisions for credit "
            "losses $4.92B in 2023, up from $2.18B in 2022."
        ),
        "keywords": ["american express", "amex", "10-k", "2023", "credit risk",
                     "non-interest", "provision"],
    },
    # --- Blackstone / CMBS demo for the multi-hop chain ---
    "doc_bx_cmbs_2025_chr": {
        "title": "BX Trust 2025-CHR Prospectus Supplement",
        "summary": (
            "Most recent Blackstone-sponsored CMBS issuance (priced Feb 2025). Single-asset "
            "single-borrower (SASB) deal collateralized by the Hilton Times Square hotel. "
            "Senior A tranche $480M, AAA-rated, 5-year term, WAL of 4.83 years. Sponsored "
            "by affiliates of Blackstone Real Estate."
        ),
        "keywords": ["blackstone", "bx", "cmbs", "trust", "2025", "hilton", "tenant",
                     "senior", "tranche", "wal", "prospectus"],
    },
    "doc_hilton_corp_structure": {
        "title": "Hilton Worldwide Holdings Inc. Corporate Structure Disclosure",
        "summary": (
            "Hilton Times Square is operated by a subsidiary of Hilton Worldwide Holdings Inc. "
            "(NYSE: HLT). Parent company is Hilton Worldwide Holdings Inc."
        ),
        "keywords": ["hilton", "worldwide", "holdings", "parent", "corporate", "structure", "hlt"],
    },
    "doc_hilton_rating_report": {
        "title": "S&P Global Ratings — Hilton Worldwide Holdings Inc.",
        "summary": (
            "S&P assigns Hilton Worldwide Holdings Inc. a corporate credit rating of BB+ "
            "with stable outlook (last affirmed Q4 2024). Moody's equivalent: Ba1."
        ),
        "keywords": ["hilton", "rating", "credit", "s&p", "moody's", "bb+", "ba1"],
    },
}


class MockDocCatalog(DocCatalog):
    """Keyword-scored doc summary search. Stand-in for your embedding index."""

    def __init__(self, docs: dict | None = None) -> None:
        self.docs = docs if docs is not None else MOCK_DOCS

    def find(self, query: str, k: int = 20) -> list[dict]:
        q_lower = query.lower()
        q_tokens = set(_tokenize(q_lower))
        scored: list[tuple[float, str, dict]] = []
        for doc_id, meta in self.docs.items():
            kws = set(_tokenize(" ".join(meta["keywords"])))
            # Overlap score + bonus for substring matches in title
            overlap = len(q_tokens & kws)
            title_bonus = sum(1 for t in q_tokens if t in meta["title"].lower())
            score = overlap + 0.5 * title_bonus
            if score > 0:
                scored.append((score, doc_id, meta))
        scored.sort(key=lambda x: -x[0])
        return [
            {
                "doc_id": doc_id,
                "title": meta["title"],
                "summary": meta["summary"],
                "score": score,
            }
            for score, doc_id, meta in scored[:k]
        ]


class MockRAGBackend(RAGBackend):
    """Simulates the user's existing multi-doc RAG endpoint via an LLM extraction call.

    In production this class should wrap an HTTP call to your real endpoint and
    map its response to {'chunks': [Chunk(...)], 'answer': str}.
    """

    def __init__(self, llm_client, docs: dict | None = None) -> None:
        self.llm = llm_client
        self.docs = docs if docs is not None else MOCK_DOCS

    def query(self, query: str, doc_ids: list[str]) -> dict:
        # Build context from doc summaries (acting as "retrieved chunks")
        context_blocks: list[str] = []
        chunks: list[Chunk] = []
        for i, doc_id in enumerate(doc_ids):
            meta = self.docs.get(doc_id)
            if meta is None:
                continue
            chunk_id = f"{doc_id}_chunk_0"
            context_blocks.append(f"[{chunk_id}] {meta['title']}\n{meta['summary']}")
            chunks.append(
                Chunk(
                    chunk_id=chunk_id,
                    text=meta["summary"],
                    doc_id=doc_id,
                    score=1.0 - (i * 0.05),
                )
            )

        if not chunks:
            return {"chunks": [], "answer": "No documents matched the requested doc_ids."}

        context = "\n\n".join(context_blocks)
        system = (
            "You are a retrieval-grounded answer extractor in a multi-hop RAG pipeline. "
            "Answer the query using ONLY the provided document excerpts. "
            "Be concise and structured. If the answer is numeric (amounts, dates, percentages), "
            "give specific values. Cite the source chunk_id in square brackets like [chunk_id]. "
            "If the documents do not contain the information, reply exactly: 'Not found in provided docs.'"
        )
        user = f"Query: {query}\n\nDocument excerpts:\n{context}\n\nAnswer:"
        answer = self.llm.complete(system=system, user=user, max_tokens=512, temperature=0.0)
        return {"chunks": chunks, "answer": answer.strip()}


def _tokenize(text: str) -> list[str]:
    import re

    return [t for t in re.split(r"[\s,;:()\[\]/]+", text.lower()) if t]
