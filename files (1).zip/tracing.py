"""Tracer: structured logging with timing for every event in the pipeline.

Logs to console (rich, colored) and accumulates a JSON-serializable trace for
post-hoc inspection. Each event carries an elapsed-time-from-start so you can
read the trace top-to-bottom and see exactly which hops ran when.
"""

from __future__ import annotations

import json
import time
from dataclasses import asdict, dataclass, field
from typing import Any, Optional

from rich.console import Console
from rich.table import Table
from rich.tree import Tree


@dataclass
class TraceEvent:
    timestamp: float
    elapsed_ms: float
    phase: str
    event_type: str
    details: dict[str, Any] = field(default_factory=dict)


class Tracer:
    """Append-only log of pipeline events with elapsed timing."""

    PHASE_COLORS = {
        "agent": "white",
        "planner": "magenta",
        "executor": "cyan",
        "tool": "yellow",
        "memory": "green",
        "synth": "blue",
    }

    def __init__(self, query: str, verbose: bool = True) -> None:
        self.query = query
        self.start_time = time.time()
        self.events: list[TraceEvent] = []
        self.phase_durations_ms: dict[str, float] = {}
        self.console = Console()
        self.verbose = verbose

    def log(self, phase: str, event_type: str, **details: Any) -> TraceEvent:
        now = time.time()
        event = TraceEvent(
            timestamp=now,
            elapsed_ms=(now - self.start_time) * 1000,
            phase=phase,
            event_type=event_type,
            details=details,
        )
        self.events.append(event)
        if self.verbose:
            self._print(event)
        return event

    def _print(self, event: TraceEvent) -> None:
        color = self.PHASE_COLORS.get(event.phase, "white")
        detail_str = self._format_details(event.details)
        self.console.print(
            f"[dim]{event.elapsed_ms:8.1f}ms[/dim] "
            f"[{color}]{event.phase:>9}[/{color}] "
            f"[bold]{event.event_type}[/bold] "
            f"{detail_str}",
            highlight=False,
        )

    @staticmethod
    def _format_details(details: dict[str, Any]) -> str:
        parts: list[str] = []
        for k, v in details.items():
            if isinstance(v, str) and len(v) > 200:
                v = v[:197] + "..."
            elif isinstance(v, (list, dict)) and len(str(v)) > 200:
                v = str(v)[:197] + "..."
            parts.append(f"[dim]{k}=[/dim]{v}")
        return " ".join(parts)

    def phase_timer(self, phase: str) -> "PhaseTimer":
        return PhaseTimer(self, phase)

    def total_ms(self) -> float:
        return (time.time() - self.start_time) * 1000

    # ---- summaries ----

    def summary(self) -> dict[str, Any]:
        by_phase: dict[str, int] = {}
        for e in self.events:
            by_phase[e.phase] = by_phase.get(e.phase, 0) + 1
        return {
            "total_ms": self.total_ms(),
            "event_count": len(self.events),
            "events_by_phase": by_phase,
            "phase_durations_ms": dict(self.phase_durations_ms),
        }

    def to_dict(self) -> dict[str, Any]:
        return {
            "query": self.query,
            "total_ms": self.total_ms(),
            "events": [asdict(e) for e in self.events],
            "summary": self.summary(),
        }

    def save_json(self, path: str) -> None:
        with open(path, "w") as f:
            json.dump(self.to_dict(), f, indent=2, default=str)

    # ---- pretty final report ----

    def print_summary(self) -> None:
        s = self.summary()
        table = Table(title="Trace summary", show_header=True, header_style="bold")
        table.add_column("Metric")
        table.add_column("Value", justify="right")
        table.add_row("Total wall-clock", f"{s['total_ms']:.1f} ms")
        table.add_row("Total events", str(s["event_count"]))
        table.add_section()
        for phase, ms in s["phase_durations_ms"].items():
            table.add_row(f"  phase: {phase}", f"{ms:.1f} ms")
        table.add_section()
        for phase, count in s["events_by_phase"].items():
            table.add_row(f"  events in {phase}", str(count))
        self.console.print(table)

    def print_reasoning_path(self, memory: Any) -> None:
        """Render the reasoning path as a tree: ordered hops with their answers."""
        tree = Tree("[bold]Reasoning path (hops in completion order)[/bold]")
        for nid, entry in memory.answer_log.items():
            sub = entry.sub_query
            if len(sub) > 100:
                sub = sub[:97] + "..."
            ans = entry.answer
            if len(ans) > 240:
                ans = ans[:237] + "..."
            branch = tree.add(f"[cyan bold]{nid}[/cyan bold]  [dim]sub_query:[/dim] {sub}")
            branch.add(f"[yellow]answer:[/yellow] {ans}")
        self.console.print(tree)

    def print_dag(self, dag: Any) -> None:
        """Render the planner's DAG as a tree showing dependencies."""
        tree = Tree("[bold]Planned DAG[/bold]")
        for nid, node in dag.nodes.items():
            args_str = str(node.args)
            if len(args_str) > 120:
                args_str = args_str[:117] + "..."
            label = (
                f"[cyan bold]{nid}[/cyan bold] "
                f"[magenta]{node.tool.value}[/magenta] "
                f"[dim]depends_on={node.depends_on}[/dim]"
            )
            branch = tree.add(label)
            branch.add(f"[dim]args:[/dim] {args_str}")
        self.console.print(tree)


class PhaseTimer:
    """Context manager that records a phase's wall-clock duration on the tracer."""

    def __init__(self, tracer: Tracer, phase: str) -> None:
        self.tracer = tracer
        self.phase = phase
        self._start: Optional[float] = None

    def __enter__(self) -> "PhaseTimer":
        self._start = time.time()
        return self

    def __exit__(self, *exc: Any) -> None:
        assert self._start is not None
        elapsed_ms = (time.time() - self._start) * 1000
        # Accumulate (in case a phase is timed multiple times, e.g. with replan loops)
        self.tracer.phase_durations_ms[self.phase] = (
            self.tracer.phase_durations_ms.get(self.phase, 0.0) + elapsed_ms
        )
