"""Multi-hop RAG agent with DAG executor and evidence memory."""

__version__ = "0.1.0"
