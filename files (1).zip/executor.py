"""DAG executor: dispatches ready nodes in parallel, resolves placeholders,
writes results to evidence memory.

This is the heart of the agent. Each `_execute_node` call corresponds to one
hop. The executor blocks dependent hops until their inputs land in answer_log.
"""

from __future__ import annotations

import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any

from .memory import EvidenceMemory
from .models import AnswerEntry, Chunk, DAG, NodeState, PlanNode, ToolType
from .tools import DocCatalog, RAGBackend
from .tracing import Tracer


class DAGExecutor:
    def __init__(
        self,
        catalog: DocCatalog,
        rag: RAGBackend,
        llm_client,
        max_workers: int = 4,
    ) -> None:
        self.catalog = catalog
        self.rag = rag
        self.llm = llm_client
        self.max_workers = max_workers

    def run(self, dag: DAG, memory: EvidenceMemory, tracer: Tracer) -> EvidenceMemory:
        completed: set[str] = set()
        batch_num = 0

        with ThreadPoolExecutor(max_workers=self.max_workers) as pool:
            while not dag.all_done(completed):
                ready = dag.ready_nodes(completed)
                if not ready:
                    pending = [
                        n.node_id for n in dag.nodes.values()
                        if n.state == NodeState.PENDING
                    ]
                    raise RuntimeError(
                        f"DAG deadlock. completed={sorted(completed)} pending={pending}"
                    )

                batch_num += 1
                batch_start = time.time()
                tracer.log(
                    "executor", "batch_dispatch",
                    batch=batch_num,
                    parallel_nodes=[n.node_id for n in ready],
                    parallel_width=len(ready),
                    completed_so_far=sorted(completed),
                )

                futures: dict[Any, PlanNode] = {}
                for node in ready:
                    node.state = NodeState.RUNNING
                    fut = pool.submit(self._execute_node, node, memory, tracer)
                    futures[fut] = node

                for fut in as_completed(futures):
                    node = futures[fut]
                    try:
                        fut.result()
                        node.state = NodeState.DONE
                        completed.add(node.node_id)
                    except Exception as e:
                        node.state = NodeState.FAILED
                        tracer.log(
                            "executor", "node_failed",
                            node_id=node.node_id, error=str(e),
                            error_type=type(e).__name__,
                        )
                        raise

                tracer.log(
                    "executor", "batch_complete",
                    batch=batch_num,
                    elapsed_ms=round((time.time() - batch_start) * 1000, 1),
                )

        return memory

    # ---- per-node dispatch ----

    def _execute_node(
        self, node: PlanNode, memory: EvidenceMemory, tracer: Tracer
    ) -> None:
        node_start = time.time()

        original_args = dict(node.args)
        resolved_args = memory.resolve_args(node.args)
        placeholders_changed = original_args != resolved_args

        tracer.log(
            "executor", "node_dispatch",
            node_id=node.node_id,
            tool=node.tool.value,
            original_args=original_args,
            resolved_args=resolved_args,
            placeholders_resolved=placeholders_changed,
        )

        if node.tool == ToolType.FIND_DOCS:
            answer = self._find_docs(node, resolved_args, memory, tracer)
        elif node.tool == ToolType.QUERY_DOCS:
            answer = self._query_docs(node, resolved_args, memory, tracer)
        elif node.tool == ToolType.COMPUTE:
            answer = self._compute(node, resolved_args, memory, tracer)
        else:
            raise ValueError(f"Unknown tool: {node.tool}")

        entry = AnswerEntry(
            node_id=node.node_id,
            sub_query=_serialize_args(resolved_args),
            answer=answer,
            iteration_id=node.iteration_id,
        )
        memory.write_answer(entry)

        elapsed_ms = (time.time() - node_start) * 1000
        tracer.log(
            "executor", "node_complete",
            node_id=node.node_id,
            elapsed_ms=round(elapsed_ms, 1),
            answer_preview=answer[:160],
            mem_after=memory.summary(),
        )

    # ---- tool calls ----

    def _find_docs(
        self,
        node: PlanNode,
        args: dict[str, Any],
        memory: EvidenceMemory,
        tracer: Tracer,
    ) -> str:
        query = args.get("query", "")
        k = int(args.get("k", 20))
        tracer.log("tool", "find_documents_call", node_id=node.node_id, query=query, k=k)
        results = self.catalog.find(query, k=k)
        doc_ids = [r["doc_id"] for r in results]
        memory.add_docs(doc_ids)
        formatted_lines = "\n".join(f"- {r['doc_id']}: {r['title']}" for r in results)
        answer = f"Found {len(results)} documents:\n{formatted_lines}"
        tracer.log(
            "tool", "find_documents_result",
            node_id=node.node_id,
            n_docs=len(results),
            doc_ids=doc_ids[:10],
        )
        return answer

    def _query_docs(
        self,
        node: PlanNode,
        args: dict[str, Any],
        memory: EvidenceMemory,
        tracer: Tracer,
    ) -> str:
        query = args.get("query", "")
        doc_filter = args.get("doc_filter")

        # Resolve doc_filter to a concrete doc_ids list
        doc_ids = self._resolve_doc_filter(doc_filter, memory)

        tracer.log(
            "tool", "query_documents_call",
            node_id=node.node_id, query=query,
            n_docs=len(doc_ids),
            doc_filter_spec=doc_filter,
            doc_ids=doc_ids[:10],
        )
        result = self.rag.query(query, doc_ids)
        chunks: list[Chunk] = result.get("chunks", [])
        answer: str = result.get("answer", "")
        memory.add_chunks(chunks, node_id=node.node_id)

        tracer.log(
            "tool", "query_documents_result",
            node_id=node.node_id,
            n_chunks=len(chunks),
            answer_preview=answer[:160],
        )
        return answer

    def _compute(
        self,
        node: PlanNode,
        args: dict[str, Any],
        memory: EvidenceMemory,
        tracer: Tracer,
    ) -> str:
        # 'task' field already has placeholders resolved at this point
        task = args.get("task", "")
        tracer.log("tool", "compute_call", node_id=node.node_id, task_preview=task[:200])
        system = (
            "You are a reasoning step in a multi-hop RAG pipeline. The task you receive "
            "already has prior hop answers inlined where placeholders appeared. Perform "
            "the requested operation (comparison, arithmetic, counting, ranking, "
            "deduplication, aggregation). Be precise and explicit; if computing values, "
            "show the values. Keep it concise."
        )
        answer = self.llm.complete(
            system=system, user=task, max_tokens=512, temperature=0.0
        )
        tracer.log("tool", "compute_result", node_id=node.node_id, answer_preview=answer[:160])
        return answer

    # ---- helpers ----

    def _resolve_doc_filter(self, doc_filter: Any, memory: EvidenceMemory) -> list[str]:
        """Resolve a doc_filter spec into a concrete list of doc_ids.

        doc_filter can be:
          - a string like "h1" referring to a prior find_documents node — we parse
            its answer text to extract doc_ids.
          - a list of doc_ids (explicit).
          - None — fall back to the full active doc_set.
        """
        if doc_filter is None:
            return list(memory.doc_set)
        if isinstance(doc_filter, list):
            return list(doc_filter)
        if isinstance(doc_filter, str):
            if doc_filter in memory.answer_log:
                return self._parse_doc_ids_from_answer(memory.answer_log[doc_filter].answer)
            # Treat as a single doc_id if not a node ref
            return [doc_filter]
        return list(memory.doc_set)

    @staticmethod
    def _parse_doc_ids_from_answer(answer_text: str) -> list[str]:
        """find_documents answers are formatted as '- doc_id: title' lines."""
        ids: list[str] = []
        for line in answer_text.splitlines():
            line = line.strip()
            if line.startswith("- "):
                head = line[2:].split(":", 1)[0].strip()
                if head:
                    ids.append(head)
        return ids


def _serialize_args(args: dict[str, Any]) -> str:
    parts = []
    for k, v in args.items():
        v_str = str(v)
        if len(v_str) > 300:
            v_str = v_str[:297] + "..."
        parts.append(f"{k}={v_str}")
    return "; ".join(parts)
