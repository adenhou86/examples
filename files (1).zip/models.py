"""Data models for the multi-hop RAG pipeline."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Optional


class NodeState(str, Enum):
    PENDING = "pending"
    READY = "ready"
    RUNNING = "running"
    DONE = "done"
    FAILED = "failed"


class ToolType(str, Enum):
    FIND_DOCS = "find_documents"
    QUERY_DOCS = "query_documents"
    COMPUTE = "compute"  # pure reasoning over prior answers, no retrieval


@dataclass
class Chunk:
    """A retrieved chunk. Deduplicated by chunk_id in the evidence memory."""

    chunk_id: str
    text: str
    doc_id: str
    page: Optional[int] = None
    score: float = 0.0
    written_by: set = field(default_factory=set)

    def __hash__(self) -> int:
        return hash(self.chunk_id)


@dataclass
class AnswerEntry:
    """One row of the answer_log. Written by each node when it completes."""

    node_id: str
    sub_query: str  # resolved (placeholders substituted)
    answer: str
    chunk_ids: list = field(default_factory=list)
    iteration_id: int = 0  # increments on each replan


@dataclass
class PlanNode:
    """A single node in the planner-emitted DAG."""

    node_id: str
    tool: ToolType
    args: dict[str, Any]
    depends_on: list[str] = field(default_factory=list)
    state: NodeState = NodeState.PENDING
    iteration_id: int = 0

    def can_dispatch(self, completed: set[str]) -> bool:
        return all(d in completed for d in self.depends_on)


@dataclass
class DAG:
    """The planner's output: a directed acyclic graph of PlanNodes."""

    nodes: dict[str, PlanNode] = field(default_factory=dict)

    def add_node(self, node: PlanNode) -> None:
        self.nodes[node.node_id] = node

    def ready_nodes(self, completed: set[str]) -> list[PlanNode]:
        """Nodes whose dependencies are all completed and which haven't run yet."""
        return [
            n for n in self.nodes.values()
            if n.state == NodeState.PENDING and n.can_dispatch(completed)
        ]

    def all_done(self, completed: set[str]) -> bool:
        return len(completed) >= len(self.nodes)

    def to_dict(self) -> dict:
        return {
            nid: {
                "tool": n.tool.value,
                "args": n.args,
                "depends_on": n.depends_on,
                "state": n.state.value,
            }
            for nid, n in self.nodes.items()
        }
