"""LLM client abstraction. Swap providers without touching the rest of the code.

- AnthropicClient: default, uses the anthropic SDK and Claude models.
- OpenAICompatibleClient: for GLM-5.1, vLLM, OpenRouter, anything serving the
  OpenAI chat-completions schema. Pass base_url + api_key + model.
"""

from __future__ import annotations

import os
from abc import ABC, abstractmethod
from typing import Optional


class LLMClient(ABC):
    @abstractmethod
    def complete(
        self,
        system: str,
        user: str,
        max_tokens: int = 2048,
        temperature: float = 0.0,
        response_format: Optional[str] = None,
    ) -> str:
        """Single-turn completion. response_format='json' strips markdown fences."""


# ---- Anthropic ----


class AnthropicClient(LLMClient):
    def __init__(self, model: str = "claude-opus-4-7", api_key: Optional[str] = None) -> None:
        import anthropic

        self.client = anthropic.Anthropic(
            api_key=api_key or os.environ.get("ANTHROPIC_API_KEY")
        )
        self.model = model

    def complete(
        self,
        system: str,
        user: str,
        max_tokens: int = 2048,
        temperature: float = 0.0,
        response_format: Optional[str] = None,
    ) -> str:
        msg = self.client.messages.create(
            model=self.model,
            max_tokens=max_tokens,
            temperature=temperature,
            system=system,
            messages=[{"role": "user", "content": user}],
        )
        text = msg.content[0].text
        if response_format == "json":
            text = _strip_json_fences(text)
        return text


# ---- OpenAI-compatible (GLM, vLLM, OpenRouter, etc.) ----


class OpenAICompatibleClient(LLMClient):
    def __init__(self, model: str, api_key: str, base_url: str) -> None:
        from openai import OpenAI

        self.client = OpenAI(api_key=api_key, base_url=base_url)
        self.model = model

    def complete(
        self,
        system: str,
        user: str,
        max_tokens: int = 2048,
        temperature: float = 0.0,
        response_format: Optional[str] = None,
    ) -> str:
        kwargs: dict = {
            "model": self.model,
            "max_tokens": max_tokens,
            "temperature": temperature,
            "messages": [
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ],
        }
        if response_format == "json":
            kwargs["response_format"] = {"type": "json_object"}
        resp = self.client.chat.completions.create(**kwargs)
        text = resp.choices[0].message.content or ""
        if response_format == "json":
            text = _strip_json_fences(text)
        return text


def _strip_json_fences(text: str) -> str:
    """Models often wrap JSON in ```json ... ```. Strip that."""
    text = text.strip()
    if text.startswith("```json"):
        text = text[len("```json") :].strip()
    elif text.startswith("```"):
        text = text[len("```") :].strip()
    if text.endswith("```"):
        text = text[: -len("```")].strip()
    return text
