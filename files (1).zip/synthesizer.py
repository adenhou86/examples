"""Final synthesizer: reads from evidence memory and produces the user-facing answer.

This is where coverage rerank would slot in — given a budget, score each chunk
in chunks_pool against the union of sub-questions in answer_log and keep the
top-K that maximally cover them. The minimal version below just hands the LLM
the full answer_log and a capped chunk view.
"""

from __future__ import annotations

from .memory import EvidenceMemory
from .tracing import Tracer


SYNTH_SYSTEM = """You are the final synthesizer in a multi-hop RAG pipeline. You receive:
- The original user query
- An answer_log of sub-question/answer pairs (one per hop the executor ran)
- A pool of retrieved chunks with provenance (chunk_id, doc_id, written_by node_ids)

Produce the final answer. Requirements:
- Address every part of the user query explicitly. If the query has numbered sub-tasks,
  cover each one.
- Ground every factual claim with a citation in square brackets — chunk_id or doc_id.
- For comparison / ranking / "which is more" questions, state the answer explicitly.
  Do not hedge with "it depends" if the data supports a clear conclusion.
- If sub-answers conflict, note the conflict and prefer the more specific source.
- No "based on the provided information" filler. Be direct.
- Keep it tight — long enough to fully answer, no longer.
"""


class Synthesizer:
    def __init__(self, llm_client, max_chunks: int = 50) -> None:
        self.llm = llm_client
        self.max_chunks = max_chunks

    def synthesize(self, query: str, memory: EvidenceMemory, tracer: Tracer) -> str:
        tracer.log(
            "synth", "synthesis_start",
            answer_log_size=len(memory.answer_log),
            chunks_pool_size=len(memory.chunks_pool),
        )

        # Format answer_log
        ans_blocks: list[str] = []
        for nid, entry in memory.answer_log.items():
            ans_blocks.append(
                f"[{nid}] sub_query: {entry.sub_query}\n"
                f"[{nid}] answer: {entry.answer}"
            )
        ans_log_str = "\n\n".join(ans_blocks) if ans_blocks else "(empty)"

        # Format chunks (capped)
        chunks_iter = list(memory.chunks_pool.values())[: self.max_chunks]
        chunk_blocks: list[str] = []
        for c in chunks_iter:
            text = c.text
            if len(text) > 400:
                text = text[:397] + "..."
            chunk_blocks.append(
                f"[{c.chunk_id}] doc={c.doc_id} written_by={sorted(c.written_by)}\n"
                f"  {text}"
            )
        chunks_str = "\n".join(chunk_blocks) if chunk_blocks else "(empty)"

        user_msg = (
            f"User query:\n{query}\n\n"
            f"=== answer_log ===\n{ans_log_str}\n\n"
            f"=== chunks_pool (top {len(chunks_iter)}) ===\n{chunks_str}\n\n"
            f"Produce the final answer."
        )

        answer = self.llm.complete(
            system=SYNTH_SYSTEM, user=user_msg, max_tokens=2048, temperature=0.0
        )
        tracer.log("synth", "synthesis_complete", answer_length=len(answer))
        return answer
