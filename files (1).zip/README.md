# Multi-hop RAG agent

A runnable reference implementation of the planner → DAG executor → evidence
memory → synthesizer pipeline. Designed to wrap an existing multi-document
RAG endpoint (similarity → reranker → top-50 → answer) and turn it into a
multi-hop agentic tool with full reasoning traces and per-hop timing.

```
multihop_rag/
├── README.md
├── requirements.txt
├── main.py                          ← CLI entry point with example queries
└── multihop_rag/
    ├── models.py                    ← Dataclasses: DAG, PlanNode, Chunk, AnswerEntry
    ├── memory.py                    ← EvidenceMemory: chunks_pool, answer_log, doc_set
    ├── tracing.py                   ← Tracer: rich console + JSON export + reasoning tree
    ├── llm.py                       ← LLMClient ABC + Anthropic + OpenAI-compatible
    ├── tools.py                     ← RAGBackend ABC + DocCatalog ABC + mock impls
    ├── planner.py                   ← LLM planner that emits the DAG as JSON
    ├── executor.py                  ← Thread-pool DAG runner with placeholder resolution
    ├── synthesizer.py               ← Final answer over evidence memory
    └── agent.py                     ← Top-level orchestrator
```

## Quick start

```bash
pip install -r requirements.txt
export ANTHROPIC_API_KEY=sk-ant-...

# See the bundled example queries
python main.py

# Run one
python main.py --example 0

# Save the full trace for inspection
python main.py --example 2 --save-trace trace.json
```

## What you will see when you run it

Live console trace, one line per event, with elapsed time from start:

```
     0.1ms     agent run_start query=Compare the personnel compensation strategies of Apple and Visa...
     0.2ms   planner plan_request query=Compare the personnel compensation strategies of Apple and Visa...
  1842.7ms   planner plan_complete num_nodes=5 roots=['h1', 'h2']
  1843.2ms  executor batch_dispatch batch=1 parallel_nodes=['h1', 'h2'] parallel_width=2
  1843.4ms  executor node_dispatch node_id=h1 tool=find_documents original_args={'query': '...'} resolved_args={'query': '...'}
  1843.5ms      tool find_documents_call node_id=h1 query=Apple 10-K 2021 2022 2023 share-based compensation k=20
  1843.7ms      tool find_documents_result node_id=h1 n_docs=3 doc_ids=['doc_apple_10k_2023', ...]
  1845.1ms  executor node_complete node_id=h1 elapsed_ms=1.8 answer_preview=Found 3 documents: ...
  ...
  3987.4ms  executor batch_dispatch batch=2 parallel_nodes=['h3', 'h4'] parallel_width=2
  ...
  6201.0ms  executor batch_dispatch batch=3 parallel_nodes=['h5']
  ...
  7544.3ms     synth synthesis_complete answer_length=812
```

Then at the end you get a reasoning-path tree:

```
Reasoning path (hops in completion order)
├── h1  sub_query: query=Apple 10-K 2021 2022 2023 share-based compensation; k=20
│   └── answer: Found 3 documents: ...
├── h2  sub_query: query=Visa 10-K 2021 2022 2023 personnel expenses; k=20
│   └── answer: Found 3 documents: ...
├── h3  sub_query: query=share-based compensation expense by year; doc_filter=h1
│   └── answer: Apple SBC: FY21 $7.91B, FY22 $9.04B, FY23 $10.83B [doc_apple_10k_*]
├── h4  sub_query: query=personnel expenses by year; doc_filter=h2
│   └── answer: Visa personnel: FY21 $4.00B, FY22 $4.99B, FY23 $5.59B [doc_visa_10k_*]
└── h5  sub_query: task=Compute the YoY growth rate of {h3} and of {h4}...
    └── answer: Apple SBC CAGR 2021-23: 16.9%. Visa personnel CAGR: 18.2%...
```

And a phase-timing table:

```
                       Trace summary
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━┓
┃ Metric                          ┃       Value ┃
┡━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╇━━━━━━━━━━━━━┩
│ Total wall-clock                │   7544.3 ms │
│ Total events                    │          32 │
├─────────────────────────────────┼─────────────┤
│   phase: planner                │   1842.5 ms │
│   phase: executor               │   4358.5 ms │
│   phase: synth                  │   1342.9 ms │
├─────────────────────────────────┼─────────────┤
│   events in agent               │           2 │
│   events in planner             │           2 │
│   events in executor            │          16 │
│   events in tool                │          10 │
│   events in synth               │           2 │
└─────────────────────────────────┴─────────────┘
```

If you pass `--save-trace trace.json` you also get the full event log as
structured JSON, including every placeholder resolution and every tool
input/output, for post-hoc analysis.

## Integrating your existing RAG endpoint

The whole point: this code is a thin orchestrator. Your existing similarity →
top-10k → reranker → top-50 → answer endpoint plugs in via two abstract bases
in `multihop_rag/tools.py`.

### 1. Wrap your endpoint as a `RAGBackend`

```python
from multihop_rag.tools import RAGBackend
from multihop_rag.models import Chunk
import requests

class MyRAGBackend(RAGBackend):
    def __init__(self, endpoint_url: str):
        self.url = endpoint_url

    def query(self, query: str, doc_ids: list[str]) -> dict:
        resp = requests.post(self.url, json={"query": query, "doc_ids": doc_ids})
        resp.raise_for_status()
        data = resp.json()
        chunks = [
            Chunk(
                chunk_id=c["chunk_id"],
                text=c["text"],
                doc_id=c["doc_id"],
                page=c.get("page"),
                score=c.get("score", 0.0),
            )
            for c in data["chunks"]
        ]
        return {"chunks": chunks, "answer": data["answer"]}
```

### 2. Build a document catalog (the one piece you don't have yet)

`find_documents` searches over **doc-level** summaries — one entry per document,
not per chunk. At 1M docs this is roughly a 1M × 768-dim embedding matrix plus
a BM25 index over titles, which fits trivially in a Qdrant collection separate
from your chunk index.

```python
from multihop_rag.tools import DocCatalog

class QdrantDocCatalog(DocCatalog):
    def __init__(self, qdrant_client, collection: str, embed_fn):
        self.client = qdrant_client
        self.collection = collection
        self.embed = embed_fn  # e.g. Qwen3-Embedding-8B wrapper

    def find(self, query: str, k: int = 20) -> list[dict]:
        vec = self.embed(query)
        hits = self.client.search(
            collection_name=self.collection,
            query_vector=vec,
            limit=k,
        )
        return [
            {
                "doc_id": h.payload["doc_id"],
                "title": h.payload["title"],
                "summary": h.payload["summary"],
                "score": h.score,
            }
            for h in hits
        ]
```

To build the summary index from your 1M-doc corpus, run a one-time pass with
your existing pipeline: pull the first ~2000 tokens of each doc, summarize to
~150 tokens with a small model, embed the summary, write `(doc_id, title,
summary, embedding)` to a new Qdrant collection. Optionally pair with BM25
over `title + summary` and fuse with RRF — same recipe you're already using
at the chunk level.

### 3. Wire it up in `main.py`

```python
catalog = QdrantDocCatalog(qdrant, "doc_summaries", embed_fn)
rag = MyRAGBackend("https://your-rag-endpoint/query")

agent = MultiHopRAGAgent(
    planner=Planner(llm),
    executor=DAGExecutor(catalog, rag, llm, max_workers=8),
    synthesizer=Synthesizer(llm),
)
```

### Using a non-Anthropic LLM (e.g. GLM-5.1)

```python
from multihop_rag.llm import OpenAICompatibleClient

llm = OpenAICompatibleClient(
    model="glm-4.5",
    api_key=os.environ["GLM_API_KEY"],
    base_url="https://open.bigmodel.cn/api/paas/v4",
)
```

The rest of the code is provider-agnostic.

## Architecture in 30 seconds

1. **Planner** (one LLM call) takes the user query and emits a DAG of hop
   nodes as JSON. Each node specifies a tool (`find_documents`,
   `query_documents`, `compute`), args (which may contain `{hN}` placeholders),
   and a list of dependencies.

2. **Executor** runs the DAG with a thread pool. At every tick it computes
   the set of ready nodes (deps all completed), dispatches them in parallel,
   and waits. When a node fires, the executor resolves any `{hN}`
   placeholders in its args from `answer_log` and calls the appropriate tool.

3. **Evidence memory** is shared across nodes and append-only within an
   iteration. Three structures:
   - `chunks_pool`: top-50 chunks per `query_documents` call, deduplicated
     by `chunk_id`, with `written_by` set for provenance.
   - `answer_log`: one row per completed node — `(node_id, sub_query, answer)`.
     This is what placeholders read from.
   - `doc_set`: union of doc_ids surfaced by every `find_documents` call.

4. **Synthesizer** (one LLM call) reads the full `answer_log` and the
   `chunks_pool`, and produces the final user-facing answer grounded in
   chunk citations.

The trace mechanism logs every state transition and tool call with elapsed
time, so a single run gives you a complete reasoning path.

## Patterns the planner handles

- **Parallel comparison** (`Apple vs Visa`): two independent `find_documents`
  roots, two parallel `query_documents` leaves, one `compute` for the
  comparison. Wall-clock = 3 sequential batches, not 5 serial calls.
- **Single-entity aggregation** (`Chevron renewables`): one `find_documents`
  root, several parallel `query_documents` leaves (one per aspect), one
  `compute` for aggregation/counting.
- **Linear chain** (`rating of parent of largest tenant`): a sequence of
  `find_documents` / `query_documents` pairs where each hop's query uses
  `{prev_hop}` to inject the prior answer. The chain is genuinely sequential
  because no later query can be written without the prior answer.
- **Temporal** (`NVIDIA hedges Q1 vs Q2`): parallel period retrievals, one
  `compute` for the delta and explanation.

See `main.py:EXAMPLE_QUERIES` for one of each.

## Limits and next steps

This is a runnable reference, not a production system. Things you would add:

- **Coverage rerank** before synthesis. Currently `Synthesizer` hands the LLM
  all chunks; a coverage-aware rerank (LANCER-style) over the union of
  sub-questions would let you cap the chunk budget without losing recall.
- **Replan loop** for iterative refinement (the third pattern in the design
  doc). The structure is there — append nodes to `dag.nodes` at runtime and
  increment `iteration_id` — but the trigger logic (when does `evaluate`
  declare a result insufficient?) is left as an extension.
- **Caching**. Sub-queries that hash-match prior calls within the same run
  should hit a cache before round-tripping through the RAG backend.
- **Streaming**. The synthesizer call is the natural place to stream tokens
  back to the user; the executor phase usually can't be streamed
  meaningfully because parallel batches complete out of order.
- **Hop budget enforcement** via `max_hops` on the planner and a hard cap
  on `len(dag.nodes)` post-replan.
- **Token accounting** — track per-phase token spend alongside latency.

The mock backends in `tools.py` are deliberately small so you can run the
demo end-to-end with just an API key. Replacing them with the real Qdrant +
your existing RAG endpoint is the only change required to move this to
production scale.
