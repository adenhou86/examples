"""CLI entry point for the multi-hop RAG demo.

Examples:

    # List example queries
    python main.py

    # Run example 0 (Apple vs Visa comparison)
    python main.py --example 0

    # Run example 1 (Chevron renewables aggregation)
    python main.py --example 1

    # Run example 2 (Blackstone CMBS multi-hop chain)
    python main.py --example 2

    # Run a custom query
    python main.py --query "your finance query here"

    # Save the trace JSON for inspection
    python main.py --example 0 --save-trace trace.json

Set ANTHROPIC_API_KEY in your environment before running.
"""

from __future__ import annotations

import argparse
import os
import sys

from multihop_rag.agent import MultiHopRAGAgent
from multihop_rag.executor import DAGExecutor
from multihop_rag.llm import AnthropicClient
from multihop_rag.planner import Planner
from multihop_rag.synthesizer import Synthesizer
from multihop_rag.tools import MockDocCatalog, MockRAGBackend


EXAMPLE_QUERIES = [
    # [0] Parallel multi-hop comparison
    "Compare the personnel compensation strategies of Apple and Visa by analyzing: "
    "(1) Apple's share-based compensation expense trends from 2021-2023, "
    "(2) Visa's personnel expenses for the same period, "
    "and (3) which company shows higher growth rate in employee-related costs?",
    # [1] Single-entity multi-aspect aggregation
    "Trace Chevron's renewable energy strategy across its value chain by: "
    "(1) identifying upstream renewable investments (RNG, hydrogen), "
    "(2) downstream distribution infrastructure (Beyond6 stations), "
    "(3) petrochemical joint ventures with renewable components, "
    "and (4) calculating how many separate renewable initiatives are mentioned "
    "across the 2023 10-K.",
    # [2] Deep linear multi-hop chain (entity traversal)
    "What is the credit rating of the parent company of the largest tenant in the "
    "most recent Blackstone-sponsored CMBS deal?",
    # [3] Temporal multi-hop with computed delta
    "Analyze NVIDIA's cash flow hedge performance over time by: "
    "(1) comparing the net change in unrealized gains/losses for Q1 FY2025 "
    "(ended Apr 28, 2024) vs Q2 FY2024 (ended Jul 30, 2023), "
    "(2) calculating the total swing in hedge positions between these periods, "
    "and (3) explaining what market conditions might explain the shift.",
    # [4] Two-entity risk comparison
    "Compare the risk management approaches of Goldman Sachs and American Express by: "
    "(1) examining Goldman Sachs' VaR methodology and 2023 risk levels, "
    "(2) analyzing American Express' credit risk exposure through non-interest "
    "revenues, and (3) determining which firm appears more exposed to market "
    "volatility based on their disclosures.",
]


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Multi-hop RAG demo. Set ANTHROPIC_API_KEY before running."
    )
    parser.add_argument("--query", "-q", type=str, default=None)
    parser.add_argument("--example", "-e", type=int, default=None,
                        help=f"Example index (0-{len(EXAMPLE_QUERIES) - 1})")
    parser.add_argument("--model", "-m", type=str, default="claude-opus-4-7")
    parser.add_argument("--workers", "-w", type=int, default=4)
    parser.add_argument("--save-trace", type=str, default=None,
                        help="Path to dump the full trace JSON")
    parser.add_argument("--quiet", action="store_true",
                        help="Suppress live event logging (final answer still printed)")
    args = parser.parse_args()

    if args.query is None and args.example is None:
        print("Available examples:\n")
        for i, q in enumerate(EXAMPLE_QUERIES):
            preview = q[:140] + ("..." if len(q) > 140 else "")
            print(f"  [{i}] {preview}\n")
        print("Run with --example INDEX or --query 'your query'")
        return 0

    if args.example is not None:
        if not 0 <= args.example < len(EXAMPLE_QUERIES):
            print(f"--example must be 0..{len(EXAMPLE_QUERIES) - 1}")
            return 2
        query = EXAMPLE_QUERIES[args.example]
    else:
        query = args.query

    if not os.environ.get("ANTHROPIC_API_KEY"):
        print("ERROR: set ANTHROPIC_API_KEY in your environment.", file=sys.stderr)
        print(
            "(Or edit main.py to use OpenAICompatibleClient for GLM / vLLM / OpenRouter.)",
            file=sys.stderr,
        )
        return 1

    llm = AnthropicClient(model=args.model)
    catalog = MockDocCatalog()
    rag = MockRAGBackend(llm_client=llm)

    agent = MultiHopRAGAgent(
        planner=Planner(llm),
        executor=DAGExecutor(catalog, rag, llm, max_workers=args.workers),
        synthesizer=Synthesizer(llm),
    )

    result = agent.run(query, verbose=not args.quiet)

    print("\n" + "=" * 80)
    print("FINAL ANSWER")
    print("=" * 80)
    print(result["answer"])
    print("=" * 80)

    if args.save_trace:
        import json
        with open(args.save_trace, "w") as f:
            json.dump(result["trace"], f, indent=2, default=str)
        print(f"\nTrace saved to {args.save_trace}")

    return 0


if __name__ == "__main__":
    sys.exit(main())
