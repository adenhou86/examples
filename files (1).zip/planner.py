"""LLM planner: decomposes the user query into a DAG of hop nodes.

Output schema is strict JSON. The system prompt includes examples for the three
multi-hop patterns (linear chain, parallel chains, hybrid with compute synthesis)
so the planner generalizes from them.
"""

from __future__ import annotations

import json
import re

from .models import DAG, PlanNode, ToolType
from .tracing import Tracer


PLANNER_SYSTEM = """You are the planner for a multi-hop RAG agent. Given a user query,
decompose it into a directed acyclic graph (DAG) of hop nodes. Output ONLY valid JSON.

# Tools available to each hop
- "find_documents": searches the document catalog by topic/entity, returns candidate
  doc_ids. Use as a root hop whenever you need to scope to specific docs before
  retrieving content. Cheap. Always come before query_documents.
- "query_documents": retrieves chunks and answers within a doc set. This is your
  existing multi-doc RAG endpoint (similarity → rerank → top-50 → answer).
- "compute": pure LLM reasoning over prior answers in answer_log. No retrieval.
  Use for: comparison, ranking, arithmetic, counting/deduplication, aggregation,
  "which is more" / "calculate the swing" / "explain the difference".

# Node spec
Each node is a JSON object with:
- "id": short identifier, "h1" "h2" ...
- "tool": one of "find_documents", "query_documents", "compute"
- "args": object. For find_documents/query_documents: {"query": "..."}. For
  query_documents you may also include {"doc_filter": "h1"} to scope to the
  doc_ids surfaced by node h1. For compute: {"task": "..."}.
- "depends_on": list of node ids whose answers this node needs.

# Placeholders
Within args strings you may write `{hN}` to substitute the answer of node hN at
dispatch time. ANY node containing `{hN}` MUST list hN in depends_on.

# Patterns to recognize
- Two-entity comparison: separate find_documents + query_documents per entity
  (independent roots, run in parallel), final compute that compares.
- Single-entity multi-aspect: one find_documents root, several parallel
  query_documents leaves (one per aspect), optional compute for aggregation.
- Linear chain ("X of Y of Z"): sequential query_documents nodes where each
  depends on the previous and uses `{h_prev}` in its query.
- Temporal: parallel query_documents for each period, compute for the delta
  and explanation.

# Examples

## Example 1: Compare Apple vs Visa compensation 2021-2023
{
  "nodes": [
    {"id": "h1", "tool": "find_documents", "args": {"query": "Apple 10-K 2021 2022 2023 share-based compensation"}, "depends_on": []},
    {"id": "h2", "tool": "find_documents", "args": {"query": "Visa 10-K 2021 2022 2023 personnel expenses"}, "depends_on": []},
    {"id": "h3", "tool": "query_documents", "args": {"query": "share-based compensation expense by year 2021-2023", "doc_filter": "h1"}, "depends_on": ["h1"]},
    {"id": "h4", "tool": "query_documents", "args": {"query": "personnel expenses by year 2021-2023", "doc_filter": "h2"}, "depends_on": ["h2"]},
    {"id": "h5", "tool": "compute", "args": {"task": "Compute the YoY growth rate of {h3} and of {h4}, then determine which company shows higher growth in employee-related costs. Be explicit about the numbers."}, "depends_on": ["h3", "h4"]}
  ]
}

## Example 2: Credit rating of parent of largest tenant in latest Blackstone CMBS
{
  "nodes": [
    {"id": "h1", "tool": "find_documents", "args": {"query": "Blackstone sponsored CMBS deal 2024 2025"}, "depends_on": []},
    {"id": "h2", "tool": "query_documents", "args": {"query": "most recent Blackstone-sponsored CMBS deal name and date", "doc_filter": "h1"}, "depends_on": ["h1"]},
    {"id": "h3", "tool": "find_documents", "args": {"query": "prospectus largest tenant of {h2}"}, "depends_on": ["h2"]},
    {"id": "h4", "tool": "query_documents", "args": {"query": "largest tenant in the deal {h2}", "doc_filter": "h3"}, "depends_on": ["h3"]},
    {"id": "h5", "tool": "find_documents", "args": {"query": "corporate parent of {h4}"}, "depends_on": ["h4"]},
    {"id": "h6", "tool": "query_documents", "args": {"query": "parent company of {h4}", "doc_filter": "h5"}, "depends_on": ["h5"]},
    {"id": "h7", "tool": "find_documents", "args": {"query": "credit rating S&P Moody's {h6}"}, "depends_on": ["h6"]},
    {"id": "h8", "tool": "query_documents", "args": {"query": "credit rating of {h6}", "doc_filter": "h7"}, "depends_on": ["h7"]}
  ]
}

# Hard constraints
- Output ONLY the JSON object, no prose, no markdown fences.
- Maximum 12 nodes.
- Every {hN} in args MUST appear in depends_on.
- No cycles.
- IDs are h1, h2, h3, ... in some sensible order (roots first).
"""


_PLACEHOLDER_RE = re.compile(r"\{(\w+)\}")


class Planner:
    def __init__(self, llm_client) -> None:
        self.llm = llm_client

    def plan(self, query: str, tracer: Tracer) -> DAG:
        tracer.log("planner", "plan_request", query=query)

        response = self.llm.complete(
            system=PLANNER_SYSTEM,
            user=f"User query:\n{query}\n\nEmit the DAG as JSON (no markdown, no prose).",
            response_format="json",
            max_tokens=2048,
            temperature=0.0,
        )

        try:
            plan_dict = json.loads(response)
        except json.JSONDecodeError as e:
            tracer.log(
                "planner", "json_parse_failed",
                error=str(e),
                raw_response=response[:500],
            )
            raise ValueError(f"Planner returned invalid JSON: {e}\n\nRaw response:\n{response}")

        if "nodes" not in plan_dict:
            raise ValueError(f"Planner response missing 'nodes' key. Got: {list(plan_dict)}")

        dag = DAG()
        for spec in plan_dict["nodes"]:
            try:
                tool = ToolType(spec["tool"])
            except ValueError:
                raise ValueError(f"Unknown tool in plan: {spec.get('tool')}")
            node = PlanNode(
                node_id=spec["id"],
                tool=tool,
                args=spec.get("args", {}),
                depends_on=spec.get("depends_on", []),
            )
            dag.add_node(node)

        self._validate(dag)

        tracer.log(
            "planner", "plan_complete",
            num_nodes=len(dag.nodes),
            roots=[nid for nid, n in dag.nodes.items() if not n.depends_on],
        )
        return dag

    @staticmethod
    def _validate(dag: DAG) -> None:
        # Every dep must exist
        for node in dag.nodes.values():
            for dep in node.depends_on:
                if dep not in dag.nodes:
                    raise ValueError(
                        f"Node {node.node_id} depends on unknown node '{dep}'"
                    )
        # Every {hN} placeholder must be in depends_on
        for node in dag.nodes.values():
            for v in node.args.values():
                if isinstance(v, str):
                    for ref in _PLACEHOLDER_RE.findall(v):
                        if ref in dag.nodes and ref not in node.depends_on:
                            raise ValueError(
                                f"Node {node.node_id} uses placeholder {{{ref}}} but "
                                f"does not list '{ref}' in depends_on"
                            )
        # No cycles (topological sort consumes all nodes)
        in_degree = {nid: len(n.depends_on) for nid, n in dag.nodes.items()}
        queue = [nid for nid, d in in_degree.items() if d == 0]
        visited = 0
        while queue:
            nid = queue.pop()
            visited += 1
            for other in dag.nodes.values():
                if nid in other.depends_on:
                    in_degree[other.node_id] -= 1
                    if in_degree[other.node_id] == 0:
                        queue.append(other.node_id)
        if visited != len(dag.nodes):
            raise ValueError("DAG contains a cycle")
