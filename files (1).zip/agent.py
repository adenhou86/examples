"""Top-level agent: planner -> executor -> synthesizer."""

from __future__ import annotations

from typing import Any

from .executor import DAGExecutor
from .memory import EvidenceMemory
from .planner import Planner
from .synthesizer import Synthesizer
from .tracing import Tracer


class MultiHopRAGAgent:
    def __init__(
        self,
        planner: Planner,
        executor: DAGExecutor,
        synthesizer: Synthesizer,
    ) -> None:
        self.planner = planner
        self.executor = executor
        self.synthesizer = synthesizer

    def run(self, query: str, verbose: bool = True) -> dict[str, Any]:
        tracer = Tracer(query=query, verbose=verbose)
        memory = EvidenceMemory()

        tracer.log("agent", "run_start", query=query)

        # 1) plan
        with tracer.phase_timer("planner"):
            dag = self.planner.plan(query, tracer)
        if verbose:
            tracer.print_dag(dag)

        # 2) execute
        with tracer.phase_timer("executor"):
            self.executor.run(dag, memory, tracer)

        # 3) synthesize
        with tracer.phase_timer("synth"):
            final_answer = self.synthesizer.synthesize(query, memory, tracer)

        tracer.log("agent", "run_complete", total_ms=round(tracer.total_ms(), 1))

        if verbose:
            tracer.print_reasoning_path(memory)
            tracer.print_summary()

        return {
            "answer": final_answer,
            "trace": tracer.to_dict(),
            "memory_summary": memory.summary(),
            "dag": dag.to_dict(),
        }
