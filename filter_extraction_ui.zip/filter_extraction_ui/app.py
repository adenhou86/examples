"""Streamlit UI for the 4-stage filter extraction pipeline.

Run:
    export ANTHROPIC_API_KEY=sk-ant-...
    streamlit run app.py
"""

from __future__ import annotations

import json
import os
import time
from typing import Any

import pandas as pd
import streamlit as st

from pipeline import (
    RetrievalIndex,
    aggregate_distinct_values,
    apply_filter,
    extract_filter,
    flatten_metadata,
)


DEFAULT_QUERY = (
    "Analyze Tesla, Microsoft, and Apple's business performance and strategic changes "
    "across their latest 10-K/10-Q filings by: (1) comparing revenue growth, segment "
    "performance, operating income, margin trends, and foreign currency impacts across "
    "the three companies, (2) identifying the main drivers of performance for each "
    "company, including Tesla's Automotive vs Energy Generation and Storage businesses, "
    "Microsoft's Productivity and Business Processes vs Intelligent Cloud vs More "
    "Personal Computing segments, and Apple's iPhone, Services, Mac, iPad, and "
    "Wearables categories"
)


# ---------------------------------------------------------------------------
# Caching helpers
# ---------------------------------------------------------------------------


@st.cache_resource
def load_records(path: str) -> list[dict]:
    with open(path) as f:
        return json.load(f)


@st.cache_resource
def build_index(records_path: str) -> RetrievalIndex:
    # Note: records_path used purely as a cache key so the index rebuilds when path changes
    records = load_records(records_path)
    return RetrievalIndex(records)


@st.cache_resource
def get_llm_client():
    from anthropic import Anthropic
    return Anthropic()


# ---------------------------------------------------------------------------
# Page
# ---------------------------------------------------------------------------


st.set_page_config(
    page_title="Filter Extraction Pipeline",
    page_icon="🔎",
    layout="wide",
)

st.title("Multi-stage filter extraction pipeline")
st.caption(
    "Query → BM25+TF-IDF retrieval (top K) → distinct-values observation → "
    "LLM filter extractor → applied to full catalog → final doc_ids"
)

# Sidebar configuration
with st.sidebar:
    st.header("Configuration")

    json_path = st.text_input("Catalog JSON path", value="mock_metadata.json")
    uploaded = st.file_uploader("...or upload a JSON file", type=["json"])

    top_k = st.slider(
        "Top K (Stage 1)",
        min_value=20, max_value=500, value=100, step=20,
        help="Number of candidates retrieved by BM25+TF-IDF before observation.",
    )

    model = st.selectbox(
        "Filter extractor model (Stage 3)",
        options=[
            "claude-haiku-4-5-20251001",
            "claude-sonnet-4-6",
            "claude-opus-4-7",
        ],
        index=0,
        help="Haiku is cheap and fast; usually sufficient. Step up if filter quality is poor.",
    )

    current_date = st.text_input(
        "Current date (for relative time phrases)",
        value="2026-05-21",
    )

    st.divider()
    st.caption("Requires `ANTHROPIC_API_KEY` in env.")


# Load records
if uploaded is not None:
    try:
        records = json.load(uploaded)
        source_label = f"upload ({uploaded.name})"
    except Exception as e:
        st.error(f"Failed to parse uploaded JSON: {e}")
        st.stop()
elif os.path.exists(json_path):
    records = load_records(json_path)
    source_label = json_path
else:
    st.error(f"Catalog file not found: {json_path}")
    st.stop()


# Build index (cache key = path; uploads rebuild every time)
if uploaded is not None:
    with st.spinner("Building BM25 + TF-IDF indexes..."):
        index = RetrievalIndex(records)
else:
    with st.spinner("Loading / building BM25 + TF-IDF indexes..."):
        index = build_index(json_path)

# Header status
c1, c2, c3 = st.columns(3)
c1.metric("Catalog size", f"{len(records):,} docs")
c2.metric("Source", source_label)
c3.metric("Top K (Stage 1)", top_k)


# Query input
st.subheader("Query")
query = st.text_area("Enter your query:", value=DEFAULT_QUERY, height=180, label_visibility="collapsed")

run = st.button("▶ Run pipeline", type="primary", use_container_width=True)


# ---------------------------------------------------------------------------
# Pipeline execution
# ---------------------------------------------------------------------------


def render_results(query: str, records: list[dict], index: RetrievalIndex,
                   top_k: int, current_date: str, model: str) -> None:
    if not query.strip():
        st.warning("Enter a query.")
        return

    if not os.environ.get("ANTHROPIC_API_KEY"):
        st.error("Set `ANTHROPIC_API_KEY` in your environment before running.")
        st.stop()

    llm = get_llm_client()

    timings: dict[str, float] = {}

    # Stage 1
    with st.spinner(f"Stage 1: BM25 + TF-IDF + RRF over {len(records)} docs..."):
        t0 = time.time()
        top_candidates = index.search(query, top_k=top_k)
        timings["stage1_retrieval"] = (time.time() - t0) * 1000

    # Stage 2
    with st.spinner("Stage 2: Aggregating distinct values..."):
        t0 = time.time()
        observation = aggregate_distinct_values(top_candidates)
        timings["stage2_observe"] = (time.time() - t0) * 1000

    # Stage 3
    with st.spinner(f"Stage 3: Extracting filter via {model}..."):
        t0 = time.time()
        try:
            filter_spec = extract_filter(
                query, observation, llm, current_date=current_date, model=model
            )
        except Exception as e:
            st.error(f"Filter extraction failed: {e}")
            st.stop()
        timings["stage3_llm"] = (time.time() - t0) * 1000

    # Stage 4
    with st.spinner(f"Stage 4: Applying filter against all {len(records)} records..."):
        t0 = time.time()
        matches = apply_filter(records, filter_spec)
        timings["stage4_apply"] = (time.time() - t0) * 1000

    total_ms = sum(timings.values())

    # ---- Timing strip ----
    st.success(f"Pipeline complete in {total_ms:,.0f} ms — {len(matches)} matching documents")
    cols = st.columns(5)
    cols[0].metric("Total", f"{total_ms:,.0f} ms")
    cols[1].metric("Stage 1 (retrieval)", f"{timings['stage1_retrieval']:,.0f} ms")
    cols[2].metric("Stage 2 (observe)", f"{timings['stage2_observe']:,.0f} ms")
    cols[3].metric("Stage 3 (LLM)", f"{timings['stage3_llm']:,.0f} ms")
    cols[4].metric("Stage 4 (apply)", f"{timings['stage4_apply']:,.0f} ms")

    # ---- Stage tabs ----
    tab1, tab2, tab3, tab4 = st.tabs([
        f"① Stage 1 — Top {len(top_candidates)} retrieved",
        "② Stage 2 — Observation (distinct values)",
        "③ Stage 3 — Extracted filter spec",
        f"④ Stage 4 — Final matches ({len(matches)} docs)",
    ])

    with tab1:
        st.markdown(
            "**BM25 + TF-IDF cosine, fused with RRF (k=60).** This is the prior — what's "
            "*plausibly* relevant. The filter extractor will see distinct values from "
            "these rows in Stage 2, but Stage 4 retrieves against the full catalog."
        )
        df1 = pd.DataFrame([
            {
                "rrf_rank": i + 1,
                "doc_id": c["doc_id"],
                "ticker": c["flat"].get("ticker") or c["flat"].get("deal_name"),
                "doc_subtype": c["flat"].get("doc_subtype"),
                "doc_date": c["flat"].get("doc_date"),
                "fiscal_year": c["flat"].get("fiscal_year"),
                "industry": c["flat"].get("industry_sector"),
                "desk": c["flat"].get("desk_name"),
                "bm25_rank": c["bm25_rank"],
                "tfidf_rank": c["tfidf_rank"],
                "rrf_score": round(c["rrf_score"], 5),
                "path": c["flat"].get("path"),
            }
            for i, c in enumerate(top_candidates)
        ])
        st.dataframe(df1, use_container_width=True, height=520, hide_index=True)

    with tab2:
        st.markdown(
            "**Compressed observation fed to the LLM in Stage 3.** Instead of sending all "
            f"{len(top_candidates)} full records (~{len(top_candidates) * 80:,} tokens of "
            "metadata), we extract distinct values per field. Date fields collapse to a "
            "range; high-cardinality fields show the top values plus total count."
        )
        st.json(observation, expanded=True)

    with tab3:
        st.markdown(
            f"**LLM ({model}) output.** This is the structured retrieval spec that gets "
            "applied to the full catalog. `must` clauses AND together; `must_not` negates; "
            "`sort_by` + `sort_order` order the results; `limit_hint` caps the count."
        )
        if "reasoning" in filter_spec:
            st.info(f"**LLM's reasoning:** {filter_spec['reasoning']}")
        st.json({k: v for k, v in filter_spec.items() if k != "reasoning"}, expanded=True)

    with tab4:
        st.markdown(
            f"**{len(matches)} documents matched the filter** (applied against all "
            f"{len(records)} records, sorted as specified)."
        )
        if not matches:
            st.warning(
                "Filter returned 0 documents. Possible causes: the extractor used a "
                "value that didn't survive Stage 2's count threshold; a `must` clause "
                "over-specified an exact value; a date range was inverted. Check Stage 3."
            )
        else:
            df4 = pd.DataFrame([
                {
                    "doc_id": m["doc_id"],
                    "ticker": m["flat"].get("ticker") or m["flat"].get("deal_name"),
                    "company": m["flat"].get("company_name") or m["flat"].get("deal_name"),
                    "doc_subtype": m["flat"].get("doc_subtype"),
                    "doc_date": m["flat"].get("doc_date"),
                    "fiscal_year": m["flat"].get("fiscal_year"),
                    "fiscal_quarter": m["flat"].get("fiscal_quarter"),
                    "industry": m["flat"].get("industry_sector"),
                    "path": m["flat"].get("path"),
                }
                for m in matches
            ])
            st.dataframe(df4, use_container_width=True, hide_index=True)

            with st.expander(f"📋 Copy doc_ids ({len(matches)})"):
                ids = [m["doc_id"] for m in matches]
                st.code(json.dumps(ids), language="json")

            with st.expander("🔍 Inspect raw records"):
                for m in matches[:30]:
                    st.json(m["record"], expanded=False)
                if len(matches) > 30:
                    st.caption(f"... and {len(matches) - 30} more")


if run:
    render_results(query, records, index, top_k, current_date, model)
else:
    st.info(
        "Enter a query above and click **Run pipeline**. The default query exercises a "
        "multi-entity comparison (Tesla / Microsoft / Apple) — the filter should narrow "
        "to those three tickers, doc_subtype in [10-K, 10-Q], and sort by doc_date desc."
    )
