"""Four-stage filter extraction pipeline.

Stage 1: BM25 + TF-IDF cosine search over the catalog, fused with RRF → top K candidates.
Stage 2: Aggregate distinct values across the top K (compressed observation).
Stage 3: LLM filter extractor — sees query + schema + observation, emits structured filter.
Stage 4: Apply filter to the FULL catalog (not just top K) → final doc_ids.

The point of staging it this way: stage 1 is a *prior over what's relevant*,
not the candidate set. Stage 4 always runs against the full corpus so we don't
inherit stage 1's recall ceiling. The LLM uses the observation to ground its
filter in real values without being told the entire schema upfront.
"""

from __future__ import annotations

import json
import re
from collections import Counter
from typing import Any, Optional

import numpy as np
from rank_bm25 import BM25Okapi
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity


# ---------------------------------------------------------------------------
# Schema helpers
# ---------------------------------------------------------------------------


def flatten_metadata(record: dict) -> dict:
    """Promote nested FolderAttributes to top-level fields with normalized keys."""
    m = record.get("metadata", {}) or {}
    flat: dict[str, Any] = {
        "doc_id": record.get("doc_id"),
        "path": m.get("Path"),
        "source": m.get("Source"),
        "deal_name": m.get("DealName"),
        "desk_name": m.get("DeskName"),
        "doc_date": m.get("DocumentDate"),
        "doc_type": m.get("DocumentType"),
        "doc_subtype": m.get("DocumentSubType"),
        "doc_group_type": m.get("DocumentGroupType"),
        "issuers": m.get("MappedIssuers") or [],
    }
    for attr in (m.get("FolderAttributes") or []):
        name = (attr.get("name") or "").lower().replace(" ", "_")
        value = attr.get("value")
        if not name or value is None:
            continue
        # Don't overwrite top-level fields with the same key (e.g. "filing_type"
        # vs "doc_subtype" both mean the subtype — keep top-level priority).
        if name not in flat:
            flat[name] = value
    # Type coercion for numeric fields
    if isinstance(flat.get("fiscal_year"), str):
        try:
            flat["fiscal_year"] = int(flat["fiscal_year"])
        except ValueError:
            pass
    return flat


def build_search_text(flat: dict) -> str:
    """Lexical surface used for BM25/TF-IDF. Concatenates field values into a bag of text."""
    parts: list[str] = []
    for k, v in flat.items():
        if k == "doc_id":
            continue
        if isinstance(v, list):
            parts.extend(str(x) for x in v)
        elif v not in (None, ""):
            parts.append(str(v))
    return " ".join(parts)


def _tokenize(text: str) -> list[str]:
    return re.findall(r"\w+", text.lower())


# ---------------------------------------------------------------------------
# Stage 1: hybrid retrieval (BM25 + TF-IDF, fused with RRF)
# ---------------------------------------------------------------------------


class RetrievalIndex:
    """Builds BM25 + TF-IDF indexes over the flattened catalog text."""

    def __init__(self, records: list[dict]) -> None:
        self.records = records
        self.flat_records = [flatten_metadata(r) for r in records]
        self.texts = [build_search_text(f) for f in self.flat_records]

        tokenized = [_tokenize(t) for t in self.texts]
        self.bm25 = BM25Okapi(tokenized)

        self.tfidf = TfidfVectorizer(lowercase=True, ngram_range=(1, 2), min_df=1)
        self.tfidf_matrix = self.tfidf.fit_transform(self.texts)

    def search(self, query: str, top_k: int = 300) -> list[dict]:
        top_k = min(top_k, len(self.records))

        q_tokens = _tokenize(query)
        bm25_scores = self.bm25.get_scores(q_tokens) if q_tokens else np.zeros(len(self.records))
        bm25_ranks = self._rank(bm25_scores)

        q_vec = self.tfidf.transform([query])
        tfidf_scores = cosine_similarity(q_vec, self.tfidf_matrix)[0]
        tfidf_ranks = self._rank(tfidf_scores)

        # Reciprocal Rank Fusion with k=60 (standard).
        rrf_k = 60
        fused: list[tuple[int, float]] = []
        for i in range(len(self.records)):
            rrf = 1.0 / (rrf_k + bm25_ranks[i] + 1) + 1.0 / (rrf_k + tfidf_ranks[i] + 1)
            fused.append((i, rrf))
        fused.sort(key=lambda x: -x[1])

        out: list[dict] = []
        for idx, rrf in fused[:top_k]:
            out.append({
                "doc_id": self.records[idx]["doc_id"],
                "flat": self.flat_records[idx],
                "bm25_score": float(bm25_scores[idx]),
                "tfidf_score": float(tfidf_scores[idx]),
                "bm25_rank": int(bm25_ranks[idx]) + 1,
                "tfidf_rank": int(tfidf_ranks[idx]) + 1,
                "rrf_score": float(rrf),
            })
        return out

    @staticmethod
    def _rank(scores: np.ndarray) -> np.ndarray:
        """Return 0-based ranks (rank 0 = highest score). Stable for ties."""
        order = np.argsort(-np.asarray(scores), kind="stable")
        ranks = np.empty(len(scores), dtype=int)
        ranks[order] = np.arange(len(scores))
        return ranks


# ---------------------------------------------------------------------------
# Stage 2: distinct-values observation
# ---------------------------------------------------------------------------


_DATE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}")


def aggregate_distinct_values(top_candidates: list[dict],
                              categorical_threshold: int = 25,
                              high_card_top_n: int = 15) -> dict:
    """Compress the top K into a per-field summary the LLM can scan in ~1-2k tokens.

    For each metadata field:
      - date-shaped values → emit min/max range
      - few distinct values (<= categorical_threshold) → emit all with counts
      - many distinct values → emit top N + total cardinality
    """
    summary: dict[str, dict] = {}
    if not top_candidates:
        return summary

    all_fields: set[str] = set()
    for cand in top_candidates:
        all_fields.update(cand["flat"].keys())
    all_fields.discard("doc_id")
    # path is noisy and high-cardinality by definition — exclude
    all_fields.discard("path")

    for field in sorted(all_fields):
        counter: Counter[str] = Counter()
        for cand in top_candidates:
            v = cand["flat"].get(field)
            if v in (None, ""):
                continue
            if isinstance(v, list):
                for item in v:
                    if item:
                        counter[str(item)] += 1
            else:
                counter[str(v)] += 1

        if not counter:
            continue

        # Detect date columns by looking at a sample of values
        sample = next(iter(counter))
        if _DATE_RE.match(sample):
            dates = sorted(d for d in counter.keys() if _DATE_RE.match(d))
            summary[field] = {
                "type": "date_range",
                "min": dates[0] if dates else None,
                "max": dates[-1] if dates else None,
                "distinct_count": len(counter),
            }
            continue

        if len(counter) <= categorical_threshold:
            summary[field] = {
                "type": "categorical",
                "values": dict(counter.most_common()),
            }
        else:
            summary[field] = {
                "type": "high_cardinality",
                "top_values": dict(counter.most_common(high_card_top_n)),
                "total_distinct": len(counter),
            }
    return summary


# ---------------------------------------------------------------------------
# Stage 3: LLM filter extractor
# ---------------------------------------------------------------------------


FILTER_EXTRACTOR_SYSTEM = """You are a structured filter extractor for a document catalog. Given a
natural-language query and an OBSERVATION of distinct field values across the most relevant
candidate documents, emit a precise filter spec that retrieves the right documents.

Output ONLY a valid JSON object with this shape (no markdown, no prose):

{
  "filter": {
    "must": [
      {"field": "<field_name>", "match": "<value>"}
      | {"field": "<field_name>", "in": ["<v1>", "<v2>", ...]}
      | {"field": "<field_name>", "range": {"gte": "...", "lte": "..."}}
      | {"field": "<field_name>", "contains": "<substring>"}
    ],
    "must_not": [ ... same shape ... ]
  },
  "semantic_query": "<topical query string>" | null,
  "sort_by": "<field_name>" | null,
  "sort_order": "desc" | "asc" | null,
  "limit_hint": <int> | null,
  "reasoning": "<one-paragraph explanation of your filter choices>"
}

Rules:
- ONLY filter on fields that appear in the observation. Don't invent fields.
- ONLY filter on values that appear in the observation (or are obvious derivations like a date range).
- For multi-entity queries (e.g. "Tesla, Microsoft, and Apple"), use `in` with multiple values, not three `must` clauses (those would be AND'd and match nothing).
- For "latest" / "most recent" / "current" → set sort_by to a date or year field, sort_order=desc. Do NOT set limit_hint unless the query asks for a fixed count (e.g. "the most recent" = 1).
- For temporal phrases:
    "last year" → date range over the last 365 days from the current date
    "H1 2024" → range gte=2024-01-01 lte=2024-06-30
    "past 2 years" → range starting (current_year - 2)
- Pure structural queries (entities, dates, doc types) → semantic_query=null.
- Topical/exploratory queries ("companies that disclose X") → populate semantic_query.
- For company-name fields like `issuers` which are lists, prefer `contains` over `match`.
"""


def extract_filter(
    query: str,
    distinct_values_summary: dict,
    llm_client: Any,
    current_date: str,
    model: str = "claude-haiku-4-5-20251001",
) -> dict:
    """Call Anthropic Haiku to translate query + observation → filter spec."""
    user_msg = (
        f"Current date: {current_date}\n\n"
        f"User query:\n{query}\n\n"
        f"=== Observation: distinct values across the top retrieved candidates ===\n"
        f"{json.dumps(distinct_values_summary, indent=2, default=str)}\n\n"
        f"Emit the JSON filter spec (no markdown, no commentary)."
    )

    response = llm_client.messages.create(
        model=model,
        max_tokens=2048,
        temperature=0.0,
        system=FILTER_EXTRACTOR_SYSTEM,
        messages=[{"role": "user", "content": user_msg}],
    )
    text = response.content[0].text.strip()
    # Strip markdown fences if the model added them
    if text.startswith("```"):
        text = re.sub(r"^```\w*\s*", "", text)
        text = re.sub(r"\s*```$", "", text)
    return json.loads(text)


# ---------------------------------------------------------------------------
# Stage 4: apply filter to records
# ---------------------------------------------------------------------------


def apply_filter(records: list[dict], filter_spec: dict) -> list[dict]:
    """Apply the LLM-emitted filter against the FULL catalog (not just top K).

    Returns matches as [{doc_id, flat, record}], optionally sorted/limited per the spec.
    """
    flat_all = [flatten_metadata(r) for r in records]
    matches: list[dict] = []
    for i, f in enumerate(flat_all):
        if _record_matches(f, filter_spec.get("filter") or {}):
            matches.append({
                "doc_id": records[i].get("doc_id"),
                "flat": f,
                "record": records[i],
            })

    sort_by = filter_spec.get("sort_by")
    if sort_by:
        reverse = (filter_spec.get("sort_order") or "asc") == "desc"
        matches.sort(key=lambda m: _sort_key(m["flat"].get(sort_by)), reverse=reverse)

    limit = filter_spec.get("limit_hint")
    if isinstance(limit, int) and limit > 0:
        matches = matches[:limit]
    return matches


def _sort_key(v: Any) -> Any:
    """Stable sort key that puts None last regardless of sort direction."""
    if v is None:
        return ""
    if isinstance(v, (int, float)):
        return v
    return str(v)


def _record_matches(flat: dict, filter_dict: dict) -> bool:
    for clause in filter_dict.get("must", []) or []:
        if not _check_clause(flat, clause):
            return False
    for clause in filter_dict.get("must_not", []) or []:
        if _check_clause(flat, clause):
            return False
    for clause in filter_dict.get("should", []) or []:
        pass  # `should` boosts ranking; we don't model that in this demo
    return True


def _check_clause(flat: dict, clause: dict) -> bool:
    field = clause.get("field")
    if not field:
        return False
    value = flat.get(field)
    if value is None and "contains" not in clause and "match" not in clause and "in" not in clause and "range" not in clause:
        return False

    if "match" in clause:
        target = clause["match"]
        if isinstance(value, list):
            return _list_contains(value, target)
        if value is None:
            return False
        return str(value).strip().lower() == str(target).strip().lower()

    if "in" in clause:
        targets = clause["in"] or []
        target_strs = [str(t).strip().lower() for t in targets]
        if isinstance(value, list):
            for v in value:
                if str(v).strip().lower() in target_strs:
                    return True
                # Also check substring (for fuzzy company name in issuers list)
                for t in target_strs:
                    if t in str(v).strip().lower():
                        return True
            return False
        if value is None:
            return False
        return str(value).strip().lower() in target_strs

    if "range" in clause:
        r = clause["range"] or {}
        if value is None:
            return False
        v_str = str(value)
        if "gte" in r and v_str < str(r["gte"]):
            return False
        if "lte" in r and v_str > str(r["lte"]):
            return False
        if "gt" in r and v_str <= str(r["gt"]):
            return False
        if "lt" in r and v_str >= str(r["lt"]):
            return False
        return True

    if "contains" in clause:
        target = str(clause["contains"]).lower()
        if isinstance(value, list):
            return any(target in str(v).lower() for v in value if v is not None)
        if value is None:
            return False
        return target in str(value).lower()

    return False


def _list_contains(lst: list, target: Any) -> bool:
    t = str(target).strip().lower()
    return any(t == str(x).strip().lower() or t in str(x).strip().lower() for x in lst if x is not None)
