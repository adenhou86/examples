# Filter extraction pipeline — Streamlit demo

A 4-stage pipeline for translating natural-language queries into structured catalog
filters, with an LLM that *observes* a sample of the data before emitting the filter
rather than being told the schema in the prompt.

```
filter_extraction_ui/
├── app.py               ← Streamlit UI
├── pipeline.py          ← 4-stage pipeline
├── generate_data.py     ← regenerates mock_metadata.json (one-shot)
├── mock_metadata.json   ← 75 records (Tesla/MSFT/Apple + distractors + CMBS noise)
├── requirements.txt
└── README.md
```

## Run

```bash
pip install -r requirements.txt
export ANTHROPIC_API_KEY=sk-ant-...
streamlit run app.py
```

The default query exercises a multi-entity comparison across Tesla, Microsoft, and
Apple. Click **Run pipeline**. The UI displays:

- **Stage 1**: top K candidates from BM25 + TF-IDF + RRF (per-doc scores and ranks visible)
- **Stage 2**: compressed distinct-values observation (what the LLM sees)
- **Stage 3**: the LLM-emitted filter spec with reasoning
- **Stage 4**: matching documents from the full catalog with the filter + sort applied

Per-stage timings are shown in the header strip.

## What each stage does

**Stage 1 — Hybrid retrieval.** Builds BM25 and TF-IDF indexes over a flattened text
representation of each record (concatenating ticker, company name, doc_subtype,
doc_date, industry, path, etc.). For each query, scores with both, ranks each, and
fuses with Reciprocal Rank Fusion (`1/(60+r_bm25) + 1/(60+r_tfidf)`). Returns the top
K (default 100) as the *prior*. This is **not** the candidate set for the final
answer — it's just what the LLM uses to ground its filter in real values.

**Stage 2 — Distinct-values observation.** Walks the top K and per field, emits one
of:
- `date_range`: `min`, `max`, distinct count (for date-shaped values)
- `categorical`: full value→count map (when ≤25 distinct values)
- `high_cardinality`: top 15 values + total count (otherwise)

This compresses ~100 records × ~12 fields into a ~1-2KB summary — vastly cheaper than
sending the full records as LLM context.

**Stage 3 — Filter extractor (LLM call, Haiku-tier).** Takes query + observation +
current date. Emits structured JSON:

```json
{
  "filter": {
    "must": [
      {"field": "ticker", "in": ["TSLA", "MSFT", "AAPL"]},
      {"field": "doc_subtype", "in": ["10-K", "10-Q"]}
    ]
  },
  "semantic_query": null,
  "sort_by": "doc_date",
  "sort_order": "desc",
  "limit_hint": null,
  "reasoning": "..."
}
```

The system prompt is strict about (a) only filtering on fields that appear in the
observation, (b) using `in` for multi-entity queries (not multiple `must` clauses,
which would AND), and (c) emitting date ranges for relative time phrases ("last
year", "H1 2024", "past 2 years").

**Stage 4 — Apply filter.** Runs the filter against **the full catalog**, not against
the top K — so the final result isn't bounded by Stage 1's recall ceiling. Supports
`match`, `in`, `range` (gte/lte/gt/lt), and `contains` operators, with `must` /
`must_not` boolean combination. Applies `sort_by` + `sort_order` and `limit_hint`
if specified.

## Try other queries

Tested examples — paste into the query box:

- `Microsoft's most recent 10-Q` — should narrow to ticker=MSFT, doc_subtype=10-Q, sort
  by doc_date desc, limit 1.
- `Tesla and Ford revenue growth past 2 years` — ticker in [TSLA, F], doc_subtype=10-K,
  fiscal_year in [2024, 2025] or doc_date range.
- `All 10-K filings from semiconductor companies` — industry_sector=Semiconductors,
  doc_subtype=10-K.
- `Latest Blackstone-sponsored CMBS deal` — desk_name=CMBS, sponsor=Blackstone, sort
  closing_date desc, limit 1.
- `Apple 10-K and 10-Q for fiscal year 2024 and 2025` — ticker=AAPL, doc_subtype in
  [10-K, 10-Q], fiscal_year in [2024, 2025].

## Regenerate or replace the catalog

The bundled `mock_metadata.json` is built by `generate_data.py`. To regenerate after
edits:

```bash
python generate_data.py
```

To use your own catalog, point the sidebar's "Catalog JSON path" at your file. The
schema expected is the same nested-FolderAttributes structure shown in the sample
records you shared — the `flatten_metadata` function in `pipeline.py` promotes those
attributes to top-level keys at load time, so you don't have to pre-flatten.

## Notes on accuracy

Two known failure modes worth watching for:

1. **The LLM filters on a value that doesn't appear in the observation.** Stage 2
   has thresholds (`categorical_threshold=25`, `high_card_top_n=15`) — values below
   the cut are invisible. If you have rare-but-correct values being silently
   dropped, lower the threshold or surface a larger Top K.
2. **Filter returns zero documents.** Stage 4 reports this clearly. A common cause
   is an over-specific exact `match` on a field where the catalog has variants
   (e.g. "Tesla, Inc." vs "Tesla"). The LLM is instructed to use `contains` for
   list-valued fields like `issuers`, but you may need to extend the prompt with
   more examples of when to relax exact-match.

For a production version: add the zero-hit fallback (drop the most-specific predicate
and retry), log the extracted filter into your tracer, and run a small eval set of
labeled query→expected-doc-ids pairs to catch regressions.
