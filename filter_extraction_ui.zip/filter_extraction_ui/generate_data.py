"""Generates mock_metadata.json with ~80 records covering target companies, distractors, and CMBS noise.

Matches the schema from the user's actual catalog:
  - top-level: DCRC, Path, Source, DealName, DeskName, DocumentDate, DocumentType,
    MappedIssuers, DocumentSubType, DocumentGroupType, AdditionalAttributes
  - nested FolderAttributes: list of {name, value} for Ticker, CIK, Filing Type,
    Fiscal Year, Industry Sector, etc.

Run once to (re)generate mock_metadata.json:
    python generate_data.py
"""

from __future__ import annotations

import json
from typing import Optional


def make_filing(
    doc_id: int,
    ticker: str,
    company: str,
    cik: str,
    industry: str,
    filing_type: str,
    fiscal_year: int,
    doc_date: str,
    fiscal_quarter: Optional[str] = None,
) -> dict:
    folder_attrs = [
        {"name": "Company Name", "value": company},
        {"name": "Ticker", "value": ticker},
        {"name": "CIK", "value": cik},
        {"name": "Filing Type", "value": filing_type},
        {"name": "Industry Sector", "value": industry},
        {"name": "Fiscal Year", "value": str(fiscal_year)},
    ]
    if fiscal_quarter:
        folder_attrs.append({"name": "Fiscal Quarter", "value": fiscal_quarter})

    doc_type_map = {
        "10-K": "Filing10K",
        "10-Q": "Filing10Q",
        "8-K": "Filing8K",
        "DEF 14A": "FilingDEF14A",
    }
    path_segment = filing_type.replace(" ", "")
    filename = f"{ticker.lower()}_{filing_type.lower().replace(' ', '').replace('-', '')}_{fiscal_year}"
    if fiscal_quarter:
        filename += f"_{fiscal_quarter.lower()}"

    return {
        "doc_id": doc_id,
        "metadata": {
            "DCRC": "DCR",
            "Path": f"EDGAR/{ticker}/{path_segment}/{filename}.pdf",
            "Source": "EDGAR",
            "DealName": company.split(",")[0],
            "DeskName": "EDGAR",
            "DocumentDate": doc_date,
            "DocumentType": doc_type_map[filing_type],
            "MappedIssuers": [company],
            "DocumentSubType": filing_type,
            "FolderAttributes": folder_attrs,
            "DocumentGroupType": "SEC Filing",
            "AdditionalAttributes": None,
        },
    }


def make_cmbs(
    doc_id: int,
    deal_name: str,
    file_label: str,
    closing_date: str,
    sponsor: Optional[str] = None,
) -> dict:
    folder_attrs = [
        {"name": "DealX hash of files for deal", "value": "5ba1a09e9d16ca9b9523c3971285b537"},
        {"name": "Product Type", "value": "Conduit"},
        {"name": "BB Deal Name", "value": deal_name},
        {"name": "Closing Date", "value": closing_date},
        {"name": "Full Deal Name", "value": f"{deal_name} Mortgage Trust"},
    ]
    if sponsor:
        folder_attrs.append({"name": "Sponsor", "value": sponsor})
    return {
        "doc_id": doc_id,
        "metadata": {
            "DCRC": "DCR",
            "Path": f"{deal_name}/PreSale/DBRS/{file_label}.pdf",
            "Source": "Manual",
            "DealName": deal_name,
            "DeskName": "CMBS",
            "DocumentDate": closing_date,
            "DocumentType": "PreSaleLoanSummaryDBRS",
            "MappedIssuers": None,
            "DocumentSubType": None,
            "FolderAttributes": folder_attrs,
            "DocumentGroupType": None,
            "AdditionalAttributes": None,
        },
    }


def build_records() -> list[dict]:
    records: list[dict] = []
    doc_id = 7559100

    # ---- Target companies (deep coverage so we have real "latest" choices) ----

    tesla = [
        ("10-K", 2022, "2022-12-31", None),
        ("10-K", 2023, "2023-12-31", None),
        ("10-K", 2024, "2024-12-31", None),
        ("10-Q", 2023, "2023-03-31", "Q1"),
        ("10-Q", 2023, "2023-06-30", "Q2"),
        ("10-Q", 2023, "2023-09-30", "Q3"),
        ("10-Q", 2024, "2024-03-31", "Q1"),
        ("10-Q", 2024, "2024-06-30", "Q2"),
        ("10-Q", 2024, "2024-09-30", "Q3"),
        ("10-Q", 2025, "2025-03-31", "Q1"),
        ("10-Q", 2025, "2025-06-30", "Q2"),
        ("10-Q", 2025, "2025-09-30", "Q3"),
        ("10-Q", 2026, "2026-03-31", "Q1"),
        ("DEF 14A", 2024, "2024-04-15", None),
        ("8-K", 2024, "2024-10-25", None),
    ]
    for ft, fy, dt, q in tesla:
        records.append(make_filing(doc_id, "TSLA", "Tesla, Inc.", "0001318605",
                                   "Automotive", ft, fy, dt, q))
        doc_id += 1

    # Microsoft (fiscal year ends June 30)
    microsoft = [
        ("10-K", 2022, "2022-06-30", None),
        ("10-K", 2023, "2023-06-30", None),
        ("10-K", 2024, "2024-06-30", None),
        ("10-K", 2025, "2025-06-30", None),
        ("10-Q", 2024, "2023-09-30", "Q1"),
        ("10-Q", 2024, "2023-12-31", "Q2"),
        ("10-Q", 2024, "2024-03-31", "Q3"),
        ("10-Q", 2025, "2024-09-30", "Q1"),
        ("10-Q", 2025, "2024-12-31", "Q2"),
        ("10-Q", 2025, "2025-03-31", "Q3"),
        ("10-Q", 2026, "2025-09-30", "Q1"),
        ("10-Q", 2026, "2025-12-31", "Q2"),
        ("10-Q", 2026, "2026-03-31", "Q3"),
        ("DEF 14A", 2024, "2024-10-15", None),
        ("8-K", 2025, "2025-04-30", None),
    ]
    for ft, fy, dt, q in microsoft:
        records.append(make_filing(doc_id, "MSFT", "Microsoft Corporation", "0000789019",
                                   "Technology", ft, fy, dt, q))
        doc_id += 1

    # Apple (fiscal year ends late September)
    apple = [
        ("10-K", 2022, "2022-09-24", None),
        ("10-K", 2023, "2023-09-30", None),
        ("10-K", 2024, "2024-09-28", None),
        ("10-K", 2025, "2025-09-27", None),
        ("10-Q", 2024, "2023-12-30", "Q1"),
        ("10-Q", 2024, "2024-03-30", "Q2"),
        ("10-Q", 2024, "2024-06-29", "Q3"),
        ("10-Q", 2025, "2024-12-28", "Q1"),
        ("10-Q", 2025, "2025-03-29", "Q2"),
        ("10-Q", 2025, "2025-06-28", "Q3"),
        ("10-Q", 2026, "2025-12-27", "Q1"),
        ("10-Q", 2026, "2026-03-28", "Q2"),
        ("DEF 14A", 2024, "2024-01-12", None),
        ("DEF 14A", 2025, "2025-01-10", None),
        ("8-K", 2025, "2025-08-01", None),
    ]
    for ft, fy, dt, q in apple:
        records.append(make_filing(doc_id, "AAPL", "Apple Inc.", "0000320193",
                                   "Technology", ft, fy, dt, q))
        doc_id += 1

    # ---- Distractor companies ----

    distractors = [
        ("NVDA", "NVIDIA Corporation", "0001045810", "Semiconductors", [
            ("10-K", 2024, "2024-01-28", None),
            ("10-K", 2025, "2025-01-26", None),
            ("10-Q", 2025, "2024-04-28", "Q1"),
            ("10-Q", 2025, "2024-07-28", "Q2"),
            ("10-Q", 2025, "2024-10-27", "Q3"),
            ("10-Q", 2026, "2025-04-27", "Q1"),
        ]),
        ("AMD", "Advanced Micro Devices, Inc.", "0000002488", "Semiconductors", [
            ("10-K", 2023, "2023-12-30", None),
            ("10-K", 2024, "2024-12-28", None),
            ("10-Q", 2025, "2025-03-29", "Q1"),
        ]),
        ("GOOGL", "Alphabet Inc.", "0001652044", "Technology", [
            ("10-K", 2023, "2023-12-31", None),
            ("10-K", 2024, "2024-12-31", None),
            ("10-Q", 2025, "2025-03-31", "Q1"),
        ]),
        ("AMZN", "Amazon.com, Inc.", "0001018724", "E-Commerce", [
            ("10-K", 2024, "2024-12-31", None),
            ("10-Q", 2025, "2025-03-31", "Q1"),
        ]),
        ("META", "Meta Platforms, Inc.", "0001326801", "Technology", [
            ("10-K", 2024, "2024-12-31", None),
        ]),
        ("JPM", "JPMorgan Chase & Co.", "0000019617", "Financials", [
            ("10-K", 2024, "2024-12-31", None),
            ("10-Q", 2025, "2025-03-31", "Q1"),
        ]),
        ("GS", "The Goldman Sachs Group, Inc.", "0000886982", "Financials", [
            ("10-K", 2024, "2024-12-31", None),
        ]),
        ("F", "Ford Motor Company", "0000037996", "Automotive", [
            ("10-K", 2024, "2024-12-31", None),
            ("10-Q", 2025, "2025-03-31", "Q1"),
        ]),
        ("INTC", "Intel Corporation", "0000050863", "Semiconductors", [
            ("10-K", 2024, "2024-12-28", None),
        ]),
        ("BX", "Blackstone Inc.", "0001393818", "Financials", [
            ("10-K", 2024, "2024-12-31", None),
        ]),
    ]

    for ticker, company, cik, industry, filings in distractors:
        for ft, fy, dt, q in filings:
            records.append(make_filing(doc_id, ticker, company, cik, industry, ft, fy, dt, q))
            doc_id += 1

    # ---- CMBS records (noise; should be excluded by the filter) ----

    cmbs = [
        ("COMM 2015-CR23", "SROA portfolio", "2015-05-15", None),
        ("COMM 2015-CR23", "La Gran Plaza", "2015-05-15", None),
        ("BX Trust 2024-CHR", "Hilton Times Square presale", "2024-08-15", "Blackstone"),
        ("BX Trust 2025-CHR", "Hilton Times Square 2025", "2025-02-15", "Blackstone"),
        ("BANK 2024-BNK48", "deal overview", "2024-10-15", None),
        ("BBCMS 2024-C30", "deal overview", "2024-11-20", None),
        ("WFCM 2023-C58", "deal overview", "2023-06-10", None),
        ("BX Trust 2023-VLT", "Las Vegas hotel", "2023-09-01", "Blackstone"),
    ]
    for deal, label, dt, sp in cmbs:
        records.append(make_cmbs(doc_id, deal, label, dt, sp))
        doc_id += 1

    return records


def main() -> None:
    records = build_records()
    out_path = "mock_metadata.json"
    with open(out_path, "w") as f:
        json.dump(records, f, indent=2)
    print(f"Wrote {len(records)} records to {out_path}")


if __name__ == "__main__":
    main()
